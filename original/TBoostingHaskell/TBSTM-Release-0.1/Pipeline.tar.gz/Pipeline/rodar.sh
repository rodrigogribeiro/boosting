echo ./ProducerConsumer 1000000 +RTS -N2 -RTS
./ProducerConsumer 1000000 +RTS -N2 -RTS
