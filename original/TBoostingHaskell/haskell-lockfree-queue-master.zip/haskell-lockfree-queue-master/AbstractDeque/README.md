See haddock in Data.Concurrent.Deque.Class

