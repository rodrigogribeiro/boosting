See haddock in Data.Concurrent.LinkedQueue
